Version 3.0.6
