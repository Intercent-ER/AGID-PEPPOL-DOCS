Ordine

Peppol BIS 3.0.4
NSO 4.3

Customization ID:
urn:fdc:peppol.eu:poacc:trns:order:3:restrictive:urn:www.agid.gov.it:trns:ordine:3.1