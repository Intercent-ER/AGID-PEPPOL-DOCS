Risposta d'Ordine

Peppol BIS 3.0.4
NSO 4.3

Customization ID:
urn:fdc:peppol.eu:poacc:trns:order_response:3:restrictive:urn:www.agid.gov.it:trns:risposta_ordine:3.0