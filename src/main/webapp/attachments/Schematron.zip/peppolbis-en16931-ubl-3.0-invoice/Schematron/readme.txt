Version 3.0.6

Contiene A-deviation per Tax category "B" (Transferred VAT).