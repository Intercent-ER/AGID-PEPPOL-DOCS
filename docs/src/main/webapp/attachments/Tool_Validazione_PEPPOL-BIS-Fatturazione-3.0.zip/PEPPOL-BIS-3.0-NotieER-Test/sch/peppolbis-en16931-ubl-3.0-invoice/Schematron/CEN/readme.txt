Version 3.0.5 hotfix
Release date	
